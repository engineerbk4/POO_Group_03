"""Marciano: contexto del patrón State."""
from __future__ import annotations

import math
import random

import pygame

from src.entidades.entidad_juego import EntidadJuego
from src.entidades.estados import EstadoMarciano, MarcianoAliado


class Marciano(EntidadJuego):
    """Contexto del patrón State: delega su comportamiento en estadoActual."""

    def __init__(self, x: float, y: float, objetivo: EntidadJuego,
                 estadoInicial: EstadoMarciano) -> None:
        super().__init__(x, y, 40, "marciano", 14)
        self.__velocidad: float = 90.0
        self.__objetivo: EntidadJuego = objetivo
        self.__estadoActual: EstadoMarciano = estadoInicial   # AGREGACIÓN: estado inyectado
        self.__rumbo: float = random.uniform(0, 2 * math.pi)
        self.__cambioRumbo: float = 0.0
        self.__curaAcumulada: float = 0.0

    def getObjetivo(self) -> EntidadJuego:
        return self.__objetivo

    def cambiarEstado(self, nuevoEstado: EstadoMarciano) -> None:
        self.__estadoActual = nuevoEstado

    def aceptaOfrenda(self) -> bool:
        return self.__estadoActual.aceptaOfrenda()

    def ofrecerMineral(self) -> None:
        self.cambiarEstado(MarcianoAliado())

    # ---- primitivas de movimiento que usan los estados ----
    def __moverPorVector(self, dx: float, dy: float, dt: float, factor: float) -> None:
        norma = math.hypot(dx, dy)
        if norma == 0:
            return
        paso = self.__velocidad * factor * dt / norma
        self.setPosicion(self._position_x + dx * paso, self._position_y + dy * paso)

    def acercarseA(self, otro: EntidadJuego, dt: float, factor: float = 1.0) -> None:
        self.__moverPorVector(otro.getX() - self._position_x,
                              otro.getY() - self._position_y, dt, factor)

    def alejarseDe(self, otro: EntidadJuego, dt: float, factor: float = 1.0) -> None:
        self.__moverPorVector(self._position_x - otro.getX(),
                              self._position_y - otro.getY(), dt, factor)

    def deambular(self, dt: float) -> None:
        self.__cambioRumbo -= dt
        if self.__cambioRumbo <= 0:
            self.__rumbo = random.uniform(0, 2 * math.pi)
            self.__cambioRumbo = random.uniform(1.0, 3.0)
        self.__moverPorVector(math.cos(self.__rumbo), math.sin(self.__rumbo), dt, 0.5)

    def apoyar(self, otro: EntidadJuego, dt: float) -> None:
        """El aliado cura 3 HP/s al explorador cuando está a su lado."""
        self.__curaAcumulada += 3 * dt
        puntos = int(self.__curaAcumulada)
        if puntos >= 1:
            otro.curar(puntos)
            self.__curaAcumulada -= puntos

    def update(self, dt: float) -> None:
        super().update(dt)
        self.__estadoActual.ejecutarAccion(self, dt)   # delegación al estado

    def _dibujarCuerpo(self, pantalla: pygame.Surface) -> None:
        cx, cy = int(self._position_x), int(self._position_y)
        color = self.__estadoActual.colorCuerpo()
        pygame.draw.line(pantalla, color, (cx, cy - 10), (cx, cy - 20), 2)
        pygame.draw.circle(pantalla, (255, 240, 120), (cx, cy - 21), 3)
        pygame.draw.circle(pantalla, color, (cx, cy), self._radio)
        for ox in (-5, 5):
            pygame.draw.circle(pantalla, (255, 255, 255), (cx + ox, cy - 3), 4)
            pygame.draw.circle(pantalla, (20, 20, 20), (cx + ox, cy - 3), 2)
