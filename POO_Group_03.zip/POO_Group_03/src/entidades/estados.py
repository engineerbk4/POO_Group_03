"""Patrón State: estados del Marciano."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from src.graficos import Color

if TYPE_CHECKING:
    from src.entidades.marciano import Marciano


class EstadoMarciano(ABC):
    """Interfaz del patrón State: cada estado define su propia acción."""

    @abstractmethod
    def ejecutarAccion(self, contexto: Marciano, dt: float) -> None:
        ...

    @abstractmethod
    def colorCuerpo(self) -> Color:
        ...

    @abstractmethod
    def aceptaOfrenda(self) -> bool:
        ...


class MarcianoAsustado(EstadoMarciano):
    DISTANCIA_PANICO: float = 220.0

    def ejecutarAccion(self, contexto: Marciano, dt: float) -> None:
        objetivo = contexto.getObjetivo()
        if contexto.distanciaA(objetivo) < self.DISTANCIA_PANICO:
            contexto.alejarseDe(objetivo, dt, 1.8)
        else:
            contexto.deambular(dt)

    def colorCuerpo(self) -> Color:
        return (130, 205, 90)

    def aceptaOfrenda(self) -> bool:
        return True


class MarcianoAliado(EstadoMarciano):
    DISTANCIA_SEGUIMIENTO: float = 70.0

    def ejecutarAccion(self, contexto: Marciano, dt: float) -> None:
        objetivo = contexto.getObjetivo()
        if contexto.distanciaA(objetivo) > self.DISTANCIA_SEGUIMIENTO:
            contexto.acercarseA(objetivo, dt, 1.6)
        else:
            contexto.apoyar(objetivo, dt)

    def colorCuerpo(self) -> Color:
        return (90, 190, 235)

    def aceptaOfrenda(self) -> bool:
        return False
