"""Nivel 1: recolectar combustible y sobrevivir."""
from __future__ import annotations

from src.niveles.nivel import Nivel
from src.tormentas.fabrica import TormentaFactory


class NivelSupervivencia(Nivel):
    def __init__(self, fabrica: TormentaFactory) -> None:
        super().__init__(1, fabrica)
        self.__mineralesObjetivo: int = 10
        self.__mineralesRecolectados: int = 0
        self.__tTormenta: float = 0.0
        self.__tCriatura: float = 0.0
        self.__contadorTormentas: int = 0

    def reiniciar(self) -> None:
        self.__mineralesRecolectados = 0
        self.__tTormenta = 5.0
        self.__tCriatura = 0.0
        self.__contadorTormentas = 0
        super().reiniciar()

    def _poblar(self) -> None:
        for _ in range(6):
            self._crearMineral()
        for _ in range(3):
            self._crearMarciano()
        for _ in range(2):
            self._crearCriatura()

    def _alRecolectar(self, valor: int) -> None:
        self.__mineralesRecolectados += valor

    def ejecutarReglas(self, dt: float) -> None:
        self.__tTormenta += dt
        self.__tCriatura += dt
        if self.__tTormenta >= 9.0:
            self.__tTormenta = 0.0
            tipo = "radiacion" if self.__contadorTormentas % 2 == 0 else "meteoritos"
            self.__contadorTormentas += 1
            self._lanzarTormenta(tipo)
        if self.__tCriatura >= 14.0 and len(self._criaturas) < 4:
            self.__tCriatura = 0.0
            self._crearCriatura()
        self._mantenerMinerales(6)

    def verificarVictoria(self) -> bool:
        return self.__mineralesRecolectados >= self.__mineralesObjetivo

    def descripcionObjetivo(self) -> str:
        return f"Recolecta combustible: {self.__mineralesRecolectados}/{self.__mineralesObjetivo}"
