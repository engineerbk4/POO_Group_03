"""Nivel 3: reunir combustible y llegar al cohete."""
from __future__ import annotations

import math
from typing import Tuple

import pygame

from src import config
from src.niveles.nivel import Nivel
from src.tormentas.fabrica import TormentaFactory


class NivelEscape(Nivel):
    COMBUSTIBLE_NECESARIO: int = 6

    def __init__(self, fabrica: TormentaFactory) -> None:
        super().__init__(3, fabrica)
        self.__cohete: Tuple[float, float] = (config.ANCHO - 90.0, config.ALTO - 90.0)
        self.__tTormenta: float = 0.0
        self.__tCriatura: float = 0.0
        self.__contadorTormentas: int = 0

    def reiniciar(self) -> None:
        self.__tTormenta = 3.0
        self.__tCriatura = 0.0
        self.__contadorTormentas = 0
        super().reiniciar()

    def _poblar(self) -> None:
        for _ in range(7):
            self._crearMineral()
        for _ in range(3):
            self._crearMarciano()
        for _ in range(2):
            self._crearCriatura()

    def __cercaDelCohete(self) -> bool:
        e = self.getExplorador()
        return math.hypot(e.getX() - self.__cohete[0], e.getY() - self.__cohete[1]) < 60

    def ejecutarReglas(self, dt: float) -> None:
        self.__tTormenta += dt
        self.__tCriatura += dt
        if self.__tTormenta >= 9.0:
            self.__tTormenta = 0.0
            tipo = "radiacion" if self.__contadorTormentas % 2 else "meteoritos"
            self.__contadorTormentas += 1
            self._lanzarTormenta(tipo)
        if self.__tCriatura >= 16.0 and len(self._criaturas) < 4:
            self.__tCriatura = 0.0
            self._crearCriatura()
        self._mantenerMinerales(5)

    def verificarVictoria(self) -> bool:
        listo = self.getExplorador().getInventarioMinerales() >= self.COMBUSTIBLE_NECESARIO
        return listo and self.__cercaDelCohete()

    def descripcionObjetivo(self) -> str:
        inv = self.getExplorador().getInventarioMinerales()
        if inv >= self.COMBUSTIBLE_NECESARIO:
            return "¡Tanque lleno! Corre al cohete (esquina inferior derecha)"
        return f"Reúne combustible para el cohete: {inv}/{self.COMBUSTIBLE_NECESARIO}"

    def _dibujarEscenario(self, pantalla: pygame.Surface) -> None:
        cx, cy = int(self.__cohete[0]), int(self.__cohete[1])
        pygame.draw.polygon(pantalla, (220, 60, 60), [(cx - 16, cy - 10), (cx, cy - 48), (cx + 16, cy - 10)])
        pygame.draw.rect(pantalla, (225, 225, 235), (cx - 16, cy - 10, 32, 46))
        pygame.draw.circle(pantalla, (60, 160, 230), (cx, cy + 6), 7)
        pygame.draw.polygon(pantalla, (220, 60, 60), [(cx - 16, cy + 36), (cx - 28, cy + 48), (cx - 16, cy + 20)])
        pygame.draw.polygon(pantalla, (220, 60, 60), [(cx + 16, cy + 36), (cx + 28, cy + 48), (cx + 16, cy + 20)])
