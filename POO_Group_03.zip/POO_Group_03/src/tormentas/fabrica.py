"""Patrón Factory Method con registro dinámico."""
from __future__ import annotations

from typing import Dict, List, Type

from src.tormentas.tormenta import Tormenta


class TormentaFactory:
    """Factory Method con registro dinámico: se registran tipos sin tocar esta clase (Open/Closed)."""

    def __init__(self) -> None:
        self.__registroTormentas: Dict[str, Type[Tormenta]] = {}

    def registrarTormenta(self, tipo: str, claseTormenta: Type[Tormenta]) -> None:
        if not tipo:
            raise ValueError("el tipo no puede estar vacío")
        self.__registroTormentas[tipo] = claseTormenta

    def crearTormenta(self, tipo: str) -> Tormenta:
        if tipo not in self.__registroTormentas:
            raise KeyError(f"Tipo de tormenta no registrado: {tipo}")
        return self.__registroTormentas[tipo]()

    def tiposDisponibles(self) -> List[str]:
        return list(self.__registroTormentas)
